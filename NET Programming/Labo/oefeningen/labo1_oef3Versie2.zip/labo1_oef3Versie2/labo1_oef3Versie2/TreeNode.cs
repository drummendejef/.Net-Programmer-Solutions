﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace labo1_oef3Versie2
{
    class TreeNode : TreeViewItem
    {
        public string name { get; set; }
        private int index = 0;

        public static TreeNode[] Nodes = new TreeNode[1000];

        public TreeNode getNode(string name)
        {
            TreeNode tn = new TreeNode();
            tn.Header = name;
            Nodes[index] = tn;
            index++;
            return tn;
        }
    }
}
